clear; clc; close all

s = tf('s');
g = (5*(s+1)*exp(-2*s))/(s*((5*s)+1));
gx = pade(g,3);
bode(gx);
margin(gx);
