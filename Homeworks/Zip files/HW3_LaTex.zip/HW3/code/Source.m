close all; clear; clc
num = [5 10];
den = [1 4 5];
g = tf(num,den);
zs = roots(num);
ps = roots(den);
gl=g/(g+1);
figure
step(gl);
infos = stepinfo(gl);
figure
rlocus(g);