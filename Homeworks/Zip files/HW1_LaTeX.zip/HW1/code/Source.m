clear; clc; close all

s=zpk('s'); % zero-pole format
G1=1/s; % plant
G2 = 2*s + 1;
G3 = 1/(s^2 +1);
G4 = s/(s+1);
H1 = 3/s;
H2 = (s-1)/(s+3);
H3 = s/((s^2) + (3*s) + 1);
H4 = 1/(s+2);
%% Calculating T2 directly
systemnames = 'G1 G2 G3 G4 H1 H2 H3 H4';
inputvar = '[y1]';
outputvar = '[G3 - H4]';
input_to_G1 = '[ y1 - H1 - H3 ]';
input_to_G2 = '[G1]';
input_to_G3 = '[G4 + G2 - H2]';
input_to_G4 = '[y1 - H1 - H3]';
input_to_H1 = '[G1]';
input_to_H2 = '[G3 - H4]';
input_to_H3 = '[G3 - H4]';
input_to_H4 = '[G3 - H4]';
sysoutname = 'T2_direct';
cleanupsysic = 'yes';
sysic
% We can change the properties of the generated plant using
% get and set comands or as following.
T2_direct.InputName={'y1'}; % Set the input names
T2_direct.OutputName={'y5'}; % Set the output names
% We can make sure that our augmented system has its minimal
% realization to avoid un-contrallability for some hidden modes
% Check zero-poles patterns and use minreal
T2_direct = minreal(T2_direct)
poles_T2_direct = pole(T2_direct) %Calculating the poles


%% Calculating T1
systemnames = 'G1 G2 G3 G4 H1 H2 H3 H4';
inputvar = '[y2]';
outputvar = '[y2 - H3 - H1]';
input_to_G1 = '[ y2 - H1 - H3 ]';
input_to_G2 = '[G1]';
input_to_G3 = '[G4 + G2 - H2]';
input_to_G4 = '[y2 - H1 - H3]';
input_to_H1 = '[G1]';
input_to_H2 = '[G3 - H4]';
input_to_H3 = '[G3 - H4]';
input_to_H4 = '[G3 - H4]';
sysoutname = 'T1';
cleanupsysic = 'yes';
sysic

T1.InputName={'y2'}; 
T1.OutputName={'y5'}; 

T1 = minreal(T1)
poles_T1 = pole(T1)



%% Calculating T2 with T1
systemnames = 'T1';
inputvar = '[y1]';
outputvar = '[T1]';
input_to_T1 = '[y1]';
sysoutname = 'T2';
cleanupsysic = 'yes';
sysic

T2.InputName={'y1'}; 
T2.OutputName={'y5'}; 

T2 = minreal(T2)
poles_T2 = pole(T2)




