clc; clear; close all

num = 1;
den = [1 -1 0];
g = tf(num,den);
figure
bode(g);
figure
nyquist(g);
grid on