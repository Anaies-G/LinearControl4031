clc; clear; close all

s = tf("s");
g = -((s+1)*(s+2)*(s+3)*(s+4))/((s^3)*(s+100));
figure
nyquist(g)
grid on
figure
bode(g)
grid on
%coefficents of Imaginary part of frequency response.
coef_im = [-90 0 3450 0 -2400];
roots_of_im = roots(coef_im);
syms jw
RealAxis_inter = [0 0 0 0];
g_abs = @(w)(sqrt(w^2+1)*sqrt(w^2+4)*sqrt(w^2+9)*sqrt(w^2+16))/(abs(w^3)*sqrt(w^2+10000));
for i=1:4
    RealAxis_inter(i) = g_abs(roots_of_im(i));
end