clc; clear; close all
%بدون تقریب
figure
s = tf("s");
g = (5*exp(-2*s)*(s+1))/(((5*s)+1)*s);
bode(g);
grid on
%با تقریب مرتبه اول
figure
gx1 = pade(g,1);
bode(gx1);
grid on
%با تقریب مرتبه اول
figure
gx2 = pade(g,2);
bode(gx2);
grid on

figure
for i=1:50
    gxn = pade(g,i);
    bode(gxn);
    grid on
    hold on
end
