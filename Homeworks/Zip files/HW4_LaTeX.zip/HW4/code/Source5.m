clc; clear; close all
%Lead controller
num = [1 0.1];
den = [1 1];
g = tf(num, den);
figure
bode(g);
figure
nyquist(g);
