clc; clear; close all

num = 1;
den = [1 11 10 0];
g = tf(num, den);
bode(g);
grid on