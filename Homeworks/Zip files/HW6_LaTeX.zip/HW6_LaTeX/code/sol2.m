clear;clc;close all hidden
s=tf('s');
G=2500/(s*(s+25));
C=1.01*(0.499*s+1)/(1.777*s+1);
GC = G*C;
margin(G)
figure
margin(GC)
figure
step(GC/(GC+1))
stepinfo(GC/(GC+1))