clc;clear;close all hidden
num = 10;
den = conv([1 2 5],[1 0]);
den2 = conv(den,[1 3]);
L = tf(num,den2);
figure
margin(L);
num3 = [28.14*30 30];
den3 = [844.25 1];
C = tf(num3,den3);
figure
margin(L*C);
