clear;close all hidden; clc
s=tf('s');
G=200/(s*(s+1)*(s+10));
margin(G)
C=0.029*(2.785*s+1);
GC=G*C;
figure
margin(GC)
figure
step(GC/(1+GC))
