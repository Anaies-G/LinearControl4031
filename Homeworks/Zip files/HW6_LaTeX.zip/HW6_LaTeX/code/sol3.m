clc; clear; close all hidden

s = tf('s');
G = exp(-0.4*s)/((0.2*s)+1);
figure
margin((1/s)*G);

G_c = 0.055 + (1.04/s);
figure
gl = (G*G_c)/(1+(G*G_c));
step(gl)
stepinfo(gl)