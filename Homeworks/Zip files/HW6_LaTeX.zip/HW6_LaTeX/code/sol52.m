clear;close all hidden;clc
s=tf('s');
G=200/(s*(s+1)*(s+10));
k_D =linspace(0.5,0.1,8);
k_P = 1/20;
for i=1:length(k_D)
    C(i) = k_P+(k_D(i)*s);
    margin(G*C(i));
    pause(1.5)
    hold on
end
