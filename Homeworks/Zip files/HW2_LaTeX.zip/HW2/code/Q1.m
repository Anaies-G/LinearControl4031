clc;clear;close all

%Question 1
num = 150.97802;
den_T = [1 4.90483 95.55571];
T = tf(num, den_T);


subplot(2,1,1)
step(T)
title('the step response of the closed-loop system')
T_info = stepinfo(T);

den_G = [1 4.90483 -55.42231];
G = tf(num, den_G);

subplot(2,1,2)
step(G)
title('the step response of the open-loop system')
G_info = stepinfo(G);