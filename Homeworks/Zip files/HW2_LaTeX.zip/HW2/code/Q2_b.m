clc;clear;close all

%Question 2, part B
%definig s and the systems
s = tf('s');
G = 0.4/(s + 0.4);
G_l = 0.4/(s + 0.8);

%step response of the systems and its information.
hold on
legend
step(G)
Ginfo = stepinfo(G);
step(G_l)
G_linfo = stepinfo(G_l);

%defining a symbolic "s" to calculate the value of E(s) or e_ss.
syms s;
G = 0.8/(2*s + 0.8);
G_l = 0.8/(2*s + 1.6);
u = 1/s;
E = (1-G)*u;
E_loop = (1-G_l)*u;
f=E*s;
f_loop = E_loop*s;
e_ss = limit(f,s,0);
e_ss_loop = limit(f_loop,s,0);
