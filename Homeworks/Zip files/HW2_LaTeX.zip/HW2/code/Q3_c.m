clc;clear;close all

%Question 3 part c, defining the system with another method
k = 8.39892;
num = k;
den = [1 4 k];
M = tf(num, den);
step(M)
M_info = stepinfo(M);