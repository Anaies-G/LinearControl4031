clc; clear; close all hidden; close all
s = tf('s');
g = exp(-6*s)*(s^2 + 3*s +1)/(5*s-1);
gx1 = pade(g,1);
figure
rlocus(gx1);
gx5 = pade(g,5);
figure
rlocus(gx5)
