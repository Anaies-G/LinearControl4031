clc;close all hidden;clear
%% Q1
data = load("Data.mat");
myStruct = data.Data;
magnitude = myStruct.magnitude;
phase = myStruct.phase;
omega = myStruct.omega;

figure
subplot(2,1,1)
semilogx(omega,20*log10(magnitude));
title('bode diagram')
xlabel('\omega')
ylabel('magnitude')
subplot(2,1,2)
semilogx(omega,phase);
xlabel('\omega')
ylabel('phase')

%% Q3
H = magnitude.*exp(1j.*deg2rad(phase));
G = tfest(idfrd(H,omega,0),3,1);
figure
bode(G)
extra = frd(H,omega,'FrequencyUnit','rad/s'); %for extra part
%% Q5 Part 1
figure
rlocus(G);
K = -11;
figure
step((K*G)/(K*G +1))

%% Q6
s = tf('s');
L = 0.1/((s^2)+(0.9*s)+9);
figure
step(L/(L+1));
stepinfo(L/(L+1))

figure
margin(L)
%% Q6 K
K = 240;
H = L*K;
figure
margin(H);
figure
step(H/(1+H));
stepinfo(H/(1+H))
%% Q6 lag
wc = 3.31;
gn = 16.6;
a = 10^(-gn/20);
T = 1.15/(a*wc);
C = K*(1+(a*T*s))/(1+(T*s));
H = L*C;
figure
margin(H);
figure
step(H/(1+H));
stepinfo(H/(1+H))

%% Q6 controller Lead
phim = 57.4;
a = (1+sin(deg2rad(phim)))/(1-sin(deg2rad(phim)));
wm = 9.52;
T =1/(wm*sqrt(a));
C2 = (1+(a*T*s))/(1+(T*s));
H = L*(C)*(C2);
figure
margin(H);
figure
step(H/(1+H));
stepinfo(H/(1+H))

%% Q7 part A, K
K7 = -2250;
H = K7*G;
t = 0:0.01:10;
figure
step(H/(s*(1+H)),t);

%% Q7 part B
s = tf('s');
C_HS = (s^3 + 0.9*s^2 + 9*s)/(s^3 + 3*s^2 + 3.5*s);
figure
rlocus(C_HS*G)
grid on
H = C_HS*G;
figure
step(H/(1+H));

H = -5*C_HS*G;
figure
step(H/(1+H));
stepinfo(H/(1+H))

H = -5.8*C_HS*G;
figure
step(H/(1+H));
stepinfo(H/(1+H))
