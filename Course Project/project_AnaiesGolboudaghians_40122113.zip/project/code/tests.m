% PD
T_p = tan(deg2rad(-129))/3.39;
P = 1+(T_p*s);
figure
step((P*L)/(1+(L*P)));
stepinfo((P*L)/(1+(P*L)))
% PI
eps = 0.05;
T_I = 1/(3.39*eps);
PI = 1+(1/(T_I*s));
figure
i=2;
j=0;
step((L*(C)^j)/(1+(L*(C)^i)));
stepinfo((L*(C)^j)/(1+(L*(C)^i)))